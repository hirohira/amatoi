<?php
// amatoi/app/Controllers/CalculatorController.php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\CsvLoader;
use App\Models\Calculator;

class CalculatorController
{
    private CsvLoader $loader;
    private Calculator $calculator;

    public function __construct()
    {
        $this->loader     = new CsvLoader();
        $this->calculator = new Calculator();
    }

    public function handleRequest(): void
    {
        // モード選択値（標準 or 谷コイル）
        $formType = $_POST['form_type'] ?? 'hyoujun';

        // プルダウン用のデータは常に読み込む
        $nokiToiList = $this->loader->loadNokiToiList();

        // ビューに渡す入力値・結果の初期化
        $inputs = [
            'formType'    => $formType,
            'sX'          => $_POST['sX']          ?? '',
            'sY'          => $_POST['sY']          ?? '',
            'sS'          => $_POST['sS']          ?? '160',
            'koubai'      => $_POST['koubai']      ?? '5',
            'sH'          => $_POST['sH']          ?? '',
            'sV'          => $_POST['sV']          ?? '',
            'nokiToiCode' => $_POST['nokiToiCode'] ?? '',
            'tateToiCode' => $_POST['tateToiCode'] ?? '',
            'sW'          => '',
            'sQ'          => '',
            'sPrimeQ'     => '',
            'result'      => '',
        ];

        // 計算実行
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['calc'])) {
            // 型変換
            $x = (float)$inputs['sX'];
            $y = (float)$inputs['sY'];
            $s = (float)$inputs['sS'];
            $i = (float)$inputs['koubai'];

            if ($formType === 'hyoujun') {
                [$w, $q, $q2, $res] = $this->calculator->calculateHyoujun(
                    $x, $y, $s, $i,
                    $inputs['nokiToiCode'],
                    $inputs['tateToiCode']
                );
            } else {
                $h = (float)$inputs['sH'];
                $v = (float)$inputs['sV'];
                [$w, $q, $q2, $res] = $this->calculator->calculateTani(
                    $x, $y, $s, $i, $h, $v, $inputs['tateToiCode']
                );
            }

            // 結果を文字列化
            $inputs['sW']      = $w;
            $inputs['sQ']      = $q;
            $inputs['sPrimeQ'] = $q2;
            $inputs['result']  = $res;
        }

        // ビューに渡す
        include __DIR__ . '/../Views/form.php';
    }
}
